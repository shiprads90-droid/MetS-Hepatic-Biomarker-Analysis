from pathlib import Path
import numpy as np
import pandas as pd
r=Path(__file__).resolve().parent
m=pd.read_csv(r/"reviewer2_outputs/all_model_results.csv")
assert len(m)==14 and not m[["Model_family","Algorithm"]].duplicated().any()
assert (m[["TN","FP","FN","TP"]].sum(axis=1)==400).all()
assert ((m.TP+m.FN)==68).all() and ((m.TN+m.FP)==332).all()
assert np.allclose(m.Sensitivity,m.TP/(m.TP+m.FN))
assert np.allclose(m.Specificity,m.TN/(m.TN+m.FP))
assert np.allclose(m.Accuracy,(m.TP+m.TN)/400)
t=r/"publication_outputs/tables"
for number in [1,2,5,6,7]:
    assert len(list(t.glob("Table_"+str(number)+"_*.csv")))==1
for name in ["Supplementary_Table_8_calibration_decision_utility.csv", "Supplementary_Table_9_hyperparameters.csv", "Supplementary_Table_10_confusion_matrices.csv"]:
    assert (t/name).is_file()
a=pd.read_csv(t/"Table_5_adjusted_associations.csv")
assert len(a)==5
for o in ["MetS","MetS_star"]:
    q=pd.read_csv(t/("Supplementary_Table_4_"+o+"_ROC.csv"))
    assert len(q)==15 and set(q.Group)=={"Overall","Female","Male"}
cm=pd.read_csv(t/"Supplementary_Table_10_confusion_matrices.csv")
assert np.array_equal(cm[["TN","FP","FN","TP"]],m[["TN","FP","FN","TP"]])
print("Checks passed: generated tables are internally consistent. This does not verify every manuscript value or source laboratory record.")
