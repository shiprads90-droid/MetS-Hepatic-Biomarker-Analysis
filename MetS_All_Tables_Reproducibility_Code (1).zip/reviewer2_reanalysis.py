import json, warnings, os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, GridSearchCV, cross_val_predict
from sklearn.metrics import roc_auc_score, brier_score_loss, confusion_matrix, roc_curve

warnings.filterwarnings('ignore')
ROOT=Path(__file__).resolve().parent
SRC=Path(os.environ.get('METS_DATA', ROOT/'upload/final shipra data with phenotype classification - Copy(20260927-112110).xlsx'))
OUT=ROOT/'reviewer2_outputs'
OUT.mkdir(exist_ok=True)
BOOT=int(os.environ.get('BOOTSTRAP_REPS','1000'))

d0=pd.read_excel(SRC,'Data')
d=d0.loc[d0['AGE'].between(18,25)].copy().reset_index(drop=True)
d['sex_bin']=d['SEX'].str.upper().eq('F').astype(int)
d['wc_high']=(d['WC  (cm)']>=np.where(d['SEX'].str.upper().eq('M'),90,80)).astype(int)
d['tg_high']=(d['TG  (mg/dl)']>=150).astype(int)
d['hdl_low']=(d['HDL   (mg/dl)']<np.where(d['SEX'].str.upper().eq('M'),40,50)).astype(int)
d['bp_high']=((d['SBP (mmHg)']>=130)|(d['DBP (mmHg)']>=85)).astype(int)
d['fbg_high']=(d['FBG  (mg/dl)']>=100).astype(int)
d['MetS_recalc']=((d[['wc_high','tg_high','hdl_low','bp_high','fbg_high']].sum(axis=1)>=3)).astype(int)
d['MetS_star']=((d[['hdl_low','bp_high','fbg_high']].sum(axis=1)>=2)).astype(int)
z=.953*np.log(d['TG  (mg/dl)'])+.139*d['BMI']+.718*np.log(d['GGT  (u/dl)'])+.053*d['WC  (cm)']-15.745
d['FLI_recalc']=100/(1+np.exp(-z))
d['mHSI_recalc']=8*d['ALT  (U/dl)']/d['AST  (U/dl)']+d['BMI']+2*d['sex_bin']
d['stored_mets']=d['Metabolic status'].astype(str).str.strip().str.lower().eq('mets').astype(int)

families={
 'Age+Sex':['AGE','sex_bin'],
 'Enzymes only':['ALT  (U/dl)','AST  (U/dl)','GGT  (u/dl)'],
 'FLI only':['FLI_recalc'],
 'mHSI only':['mHSI_recalc'],
 'Age+Sex+enzymes':['AGE','sex_bin','ALT  (U/dl)','AST  (U/dl)','GGT  (u/dl)'],
 'Age+Sex+FLI':['AGE','sex_bin','FLI_recalc'],
 'Age+mHSI':['AGE','mHSI_recalc'],
}
y=d['MetS_star'].to_numpy()

def youden(y,p):
 fpr,tpr,thr=roc_curve(y,p)
 ok=np.isfinite(thr)
 ix=np.argmax((tpr-fpr)[ok])
 return float(thr[ok][ix])

def cal_metrics(y,p):
 p=np.clip(p,1e-6,1-1e-6); lp=np.log(p/(1-p))
 try:
  fit=LogisticRegression(C=1e8,solver='lbfgs',max_iter=5000).fit(lp.reshape(-1,1),y)
  return float(fit.intercept_[0]),float(fit.coef_[0,0])
 except Exception:
  return np.nan,np.nan

def point_metrics(y,p,cls):
 tn,fp,fn,tp=confusion_matrix(y,cls,labels=[0,1]).ravel()
 ci,cs=cal_metrics(y,p)
 return dict(AUC=roc_auc_score(y,p),Brier=brier_score_loss(y,p),Cal_intercept=ci,Cal_slope=cs,
             Sensitivity=tp/(tp+fn),Specificity=tn/(tn+fp),PPV=tp/(tp+fp) if tp+fp else np.nan,
             NPV=tn/(tn+fn) if tn+fn else np.nan,Accuracy=(tp+tn)/len(y),TN=int(tn),FP=int(fp),FN=int(fn),TP=int(tp))

def strat_boot(y,p,cls,B=BOOT,seed=20261002):
 rng=np.random.default_rng(seed); i0=np.where(y==0)[0];i1=np.where(y==1)[0]
 vals=[]
 for _ in range(B):
  ix=np.r_[rng.choice(i0,len(i0),True),rng.choice(i1,len(i1),True)]
  vals.append(point_metrics(y[ix],p[ix],cls[ix]))
 keys=['AUC','Brier','Sensitivity','Specificity','PPV','NPV','Accuracy']
 return {k:(float(np.nanpercentile([v[k] for v in vals],2.5)),float(np.nanpercentile([v[k] for v in vals],97.5))) for k in keys}

rows=[]; pred_store={}
outer=StratifiedKFold(5,shuffle=True,random_state=20261002)
for fam,cols in families.items():
 X=d[cols].to_numpy(float)
 for alg in ['LR','RF']:
  oof=np.zeros(len(y)); cls=np.zeros(len(y),int); thrs=[]; selected=[]
  for fold,(tr,te) in enumerate(outer.split(X,y)):
   inner=StratifiedKFold(4,shuffle=True,random_state=20262000+fold)
   if alg=='LR':
    pipe=Pipeline([('scale',StandardScaler()),('model',LogisticRegression(max_iter=5000,solver='liblinear',random_state=100+fold))])
    grid={'model__C':[.01,.1,1,10]}
   else:
    pipe=Pipeline([('model',RandomForestClassifier(n_estimators=150,min_samples_leaf=5,max_features='sqrt',random_state=100+fold,n_jobs=-1))])
    grid={'model__max_depth':[3,5]}
   gs=GridSearchCV(pipe,grid,scoring='roc_auc',cv=inner,n_jobs=-1,refit=True)
   gs.fit(X[tr],y[tr]); best=gs.best_estimator_; selected.append(gs.best_params_)
   # Training-only threshold from inner OOF predictions using outer-fold-selected settings.
   train_oof=cross_val_predict(clone(best),X[tr],y[tr],cv=inner,method='predict_proba',n_jobs=-1)[:,1]
   thr=youden(y[tr],train_oof); thrs.append(thr)
   oof[te]=best.predict_proba(X[te])[:,1]
   cls[te]=(oof[te]>=thr).astype(int)
  met=point_metrics(y,oof,cls); ci=strat_boot(y,oof,cls)
  row={'Model_family':fam,'Algorithm':alg,'Threshold_mean':np.mean(thrs),'Threshold_SD':np.std(thrs,ddof=1),'Fold_thresholds':'; '.join(f'{x:.6f}' for x in thrs),'Selected_hyperparameters':json.dumps(selected)}
  row.update(met)
  for k,(lo,hi) in ci.items(): row[k+'_CI_low']=lo;row[k+'_CI_high']=hi
  rows.append(row);pred_store[(fam,alg)]=(oof,cls,np.array(thrs))

res=pd.DataFrame(rows)
res.to_csv(OUT/'all_model_results.csv',index=False)

# Persist the exact completed nested out-of-fold probabilities and held-out
# classifications used for Table 6 so downstream figures cannot silently refit
# a different model.
oof_frame=pd.DataFrame({'MetS_star':y})
for (fam,alg),(pp,cc,tt) in pred_store.items():
 key=(fam+'_'+alg).replace('+','_').replace(' ','_')
 oof_frame[key+'_probability']=pp
 oof_frame[key+'_classification']=cc
oof_frame.to_csv(OUT/'nested_oof_predictions.csv',index=False)

# Exploratory decision-curve values; no downstream clinical action was prespecified.
dca=[]
for (fam,alg),(pp,cc,tt) in pred_store.items():
 for pt in np.arange(.05,.31,.01):
  pred=(pp>=pt)
  tp=np.sum((pred==1)&(y==1)); fp=np.sum((pred==1)&(y==0)); n=len(y)
  nb=tp/n-(fp/n)*(pt/(1-pt))
  dca.append({'Model_family':fam,'Algorithm':alg,'Threshold_probability':round(float(pt),2),'Net_benefit':float(nb),'Interpretation':'Exploratory; no downstream clinical action prespecified'})
pd.DataFrame(dca).to_csv(OUT/'exploratory_decision_curve.csv',index=False)

# Incremental measures from LR Age+Sex to LR Age+Sex+FLI.
p0=pred_store[('Age+Sex','LR')][0];p1=pred_store[('Age+Sex+FLI','LR')][0]
case=y==1;ctrl=~case
nri_case=np.mean(p1[case]>p0[case])-np.mean(p1[case]<p0[case])
nri_ctrl=np.mean(p1[ctrl]<p0[ctrl])-np.mean(p1[ctrl]>p0[ctrl])
nri=nri_case+nri_ctrl
idi=(np.mean(p1[case])-np.mean(p1[ctrl]))-(np.mean(p0[case])-np.mean(p0[ctrl]))

# Paired, outcome-stratified bootstrap intervals conditional on the completed
# nested out-of-fold predictions. The nested procedure itself is not rerun.
rng=np.random.default_rng(20261002); i0=np.where(y==0)[0]; i1=np.where(y==1)[0]
inc=[]
for _ in range(BOOT):
 ix=np.r_[rng.choice(i0,len(i0),True),rng.choice(i1,len(i1),True)]
 yy=y[ix]; a=p0[ix]; b=p1[ix]; ca=yy==1; co=~ca
 da=roc_auc_score(yy,b)-roc_auc_score(yy,a)
 nr=(np.mean(b[ca]>a[ca])-np.mean(b[ca]<a[ca]))+(np.mean(b[co]<a[co])-np.mean(b[co]>a[co]))
 idv=(np.mean(b[ca])-np.mean(b[co]))-(np.mean(a[ca])-np.mean(a[co]))
 inc.append((da,nr,idv))
inc=np.asarray(inc); q=np.percentile(inc,[2.5,97.5],axis=0)
incremental=pd.DataFrame([{
 'Comparison':'Age + sex vs age + sex + FLI',
 'AUC_base':roc_auc_score(y,p0),'AUC_extended':roc_auc_score(y,p1),
 'Delta_AUC':roc_auc_score(y,p1)-roc_auc_score(y,p0),
 'Delta_AUC_CI_low':q[0,0],'Delta_AUC_CI_high':q[1,0],
 'Continuous_NRI':nri,'NRI_CI_low':q[0,1],'NRI_CI_high':q[1,1],
 'IDI':idi,'IDI_CI_low':q[0,2],'IDI_CI_high':q[1,2]
}])
incremental.to_csv(OUT/'incremental_nested_oof_results.csv',index=False)

audit={
 'source_n':len(d0),'analysis_n':len(d),'excluded_age_ids':d0.loc[~d0.AGE.between(18,25),'Sl. No'].tolist(),
 'female_n':int((d.SEX=='F').sum()),'male_n':int((d.SEX=='M').sum()),
 'TG_mean':float(d['TG  (mg/dl)'].mean()),'TG_SD':float(d['TG  (mg/dl)'].std(ddof=1)),
 'TG_min':float(d['TG  (mg/dl)'].min()),'TG_max':float(d['TG  (mg/dl)'].max()),'TG_unique':int(d['TG  (mg/dl)'].nunique()),
 'stored_MetS_n':int(d.stored_mets.sum()),'recalculated_MetS_n':int(d.MetS_recalc.sum()),'MetS_disagreements':int((d.stored_mets!=d.MetS_recalc).sum()),
 'MetS_star_n':int(d.MetS_star.sum()),'duplicate_identifier_values':d.loc[d['Sl. No'].duplicated(False),'Sl. No'].drop_duplicates().tolist(),
 'stored_FLI_exact_matches_published_formula':int(np.isclose(d.FLI,d.FLI_recalc,atol=1e-8).sum()),
 'stored_FLI_nonmatches_published_formula':int((~np.isclose(d.FLI,d.FLI_recalc,atol=1e-8)).sum()),
 'stored_HIS_mean_difference_from_mHSI':float((d.HIS-d.mHSI_recalc).mean()),
 'continuous_NRI_LR':float(nri),'NRI_events':float(nri_case),'NRI_nonevents':float(nri_ctrl),'IDI_LR':float(idi),
 'CI_note':'Percentile bootstrap intervals condition on completed pooled out-of-fold predictions/classifications; the full modelling procedure was not repeated within each bootstrap sample.',
 'threshold_note':'Each outer-fold threshold was selected from inner out-of-fold predictions generated using only that outer training portion and then applied to the held-out outer test fold.'
}
(OUT/'audit_summary.json').write_text(json.dumps(audit,indent=2))

# Participant-level derived audit file (no original data overwritten).
d[['Sl. No','SEX','AGE','stored_mets','MetS_recalc','MetS_star','FLI','FLI_recalc','HIS','mHSI_recalc']].to_csv(OUT/'participant_recalculation_audit.csv',index=False)
print(json.dumps(audit,indent=2))
print('\nRESULTS\n',res[['Model_family','Algorithm','AUC','Brier','Cal_intercept','Cal_slope','Sensitivity','Specificity','PPV','NPV','Accuracy','TN','FP','FN','TP','Threshold_mean']].to_string(index=False))
