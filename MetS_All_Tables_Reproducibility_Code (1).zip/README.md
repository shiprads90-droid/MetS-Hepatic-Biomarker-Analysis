# MetS main and supplementary statistical tables

Open MetS_All_Tables_Colab.ipynb in Google Colab and run the cells in order. Only the original Excel dataset needs uploading; the notebook embeds all analysis scripts. No participant data are supplied in this package.

For a local run, install requirements.txt, set METS_DATA to the original Excel path, and execute python run_all.py. The workbook must have the original Data sheet and column names. Use BOOTSTRAP_REPS=1000 for final results. Output goes to publication_outputs.

## Tables generated
- Main Tables 1 and 2: sex-specific group summaries, Welch tests, absolute pooled-SD SMDs, and BH FDR over 12 comparisons per sex.
- Main Table 5: five adjusted hepatic-marker associations with appropriate outcomes and age/sex adjustment. All ten marker/outcome combinations are exported separately as supplementary results.
- Main Table 6: all 14 nested cross-validated LR/RF combinations, conditional bootstrap intervals, calibration, operating characteristics, predictive values and confusion counts.
- Main Table 7: paired OOF delta AUC, continuous NRI and IDI with conditional intervals.
- Supplementary Tables 4A–4C: overall/female/male ROC results for both outcomes; subgroup-derived cutoffs and intervals; operating characteristics; paired outcome-stratified bootstrap comparisons against ALT. These comparisons are not DeLong tests.
- Supplementary Tables 8, 9 and 10: calibration and mean exploratory net benefit over 0.05–0.30; tuning settings; held-out confusion matrices and mean training-selected thresholds.
- Supplementary correlation, marker-by-sex interaction, adjusted-association and outer-test-fold permutation-importance tables.
- All_manuscript_tables.xlsx and Figures 1–5.

The statistical table numbering follows the current manuscript (1, 2, 5, 6, 7). No absent Tables 3 or 4 are invented. Supplementary sampling Table S1 is descriptive and cannot be calculated from this workbook.

## Corrections and limits
Figure 4 now uses outer-test-fold permutation importance, 150 trees with nested depth tuning, and ten repeats per test fold. It will differ from the previously embedded training-data figure. Main Table 1 FDR values and Table 5 regression estimates differ from the older manuscript and must be updated using regenerated CSVs. SMD values are absolute magnitudes by design. Software versions are pinned to the verified environment; statsmodels is not used. The original study data are not changed.

Model intervals condition on completed OOF predictions/classifications; they do not repeat model development. Single-marker cutoffs are descriptive. Clinical utility is exploratory. Source laboratory verification is not established by reproduction. Anonymous participant-to-college mapping is required before college-grouped validation or cluster-adjusted inference; these analyses are not claimed by this package.

## Included verified outputs
verified_aggregate_results contains aggregate tables from the source workbook named in the scripts. No participant-level records or probabilities are included. Reproduce using the unchanged workbook and pinned packages. check_generated_tables.py tests internal table consistency, not all manuscript claims.
