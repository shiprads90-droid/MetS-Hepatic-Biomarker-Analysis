"""Generate manuscript tables and figures from the unchanged study workbook.

Run reviewer2_reanalysis.py first. It performs the leakage-controlled nested
cross-validation, training-only threshold selection, conditional bootstrap CIs,
decision-curve calculations, and exports all 14 model/algorithm combinations.

Then run this file to generate the remaining manuscript outputs.
"""
from pathlib import Path
import os, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.metrics import roc_auc_score, roc_curve, confusion_matrix
from sklearn.inspection import permutation_importance
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model import LogisticRegression

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get("METS_DATA", ROOT / "upload/final shipra data with phenotype classification - Copy(20260927-112110).xlsx"))
MODEL_OUT = ROOT / "reviewer2_outputs"
OUT = ROOT / "publication_outputs"
TAB = OUT / "tables"; FIG = OUT / "figures"
TAB.mkdir(parents=True, exist_ok=True); FIG.mkdir(parents=True, exist_ok=True)
SEED = 20261002
BOOT = int(os.environ.get("BOOTSTRAP_REPS", "1000"))

COL = dict(age="AGE", sex="SEX", bmi="BMI", wc="WC  (cm)", sbp="SBP (mmHg)", dbp="DBP (mmHg)",
           fbg="FBG  (mg/dl)", tg="TG  (mg/dl)", hdl="HDL   (mg/dl)", alt="ALT  (U/dl)",
           ast="AST  (U/dl)", ggt="GGT  (u/dl)")

def load_data():
    x = pd.read_excel(DATA, sheet_name="Data")
    x = x.loc[x[COL["age"]].between(18, 25)].copy().reset_index(drop=True)
    x["sex_bin"] = x[COL["sex"]].astype(str).str.upper().eq("F").astype(int)
    x["wc_high"] = (x[COL["wc"]] >= np.where(x[COL["sex"]].str.upper().eq("M"), 90, 80)).astype(int)
    x["tg_high"] = (x[COL["tg"]] >= 150).astype(int)
    x["hdl_low"] = (x[COL["hdl"]] < np.where(x[COL["sex"]].str.upper().eq("M"), 40, 50)).astype(int)
    x["bp_high"] = ((x[COL["sbp"]] >= 130) | (x[COL["dbp"]] >= 85)).astype(int)
    x["fbg_high"] = (x[COL["fbg"]] >= 100).astype(int)
    x["MetS"] = (x[["wc_high","tg_high","hdl_low","bp_high","fbg_high"]].sum(axis=1) >= 3).astype(int)
    x["MetS_star"] = (x[["hdl_low","bp_high","fbg_high"]].sum(axis=1) >= 2).astype(int)
    z = .953*np.log(x[COL["tg"]]) + .139*x[COL["bmi"]] + .718*np.log(x[COL["ggt"]]) + .053*x[COL["wc"]] - 15.745
    x["FLI_recalc"] = 100/(1+np.exp(-z))
    x["mHSI"] = 8*x[COL["alt"]]/x[COL["ast"]] + x[COL["bmi"]] + 2*x["sex_bin"]
    return x

def fmt_mean_sd(v): return f"{np.mean(v):.2f} ± {np.std(v, ddof=1):.2f}"
def smd(a,b):
    sp=np.sqrt(((len(a)-1)*np.var(a,ddof=1)+(len(b)-1)*np.var(b,ddof=1))/(len(a)+len(b)-2))
    return abs(np.mean(a)-np.mean(b))/sp if sp else np.nan

def bh_adjust(pvalues):
    p=np.asarray(pvalues,float); order=np.argsort(p); ranked=p[order]; n=len(p)
    adj=np.minimum.accumulate((ranked*n/np.arange(1,n+1))[::-1])[::-1]
    out=np.empty(n); out[order]=np.clip(adj,0,1); return out

MARKERS = [("ALT (U/L)",COL["alt"]),("AST (U/L)",COL["ast"]),("GGT (U/L)",COL["ggt"]),
           ("FLI","FLI_recalc"),("mHSI","mHSI"),("BMI (kg/m²)",COL["bmi"]),("WC (cm)",COL["wc"]),
           ("SBP (mmHg)",COL["sbp"]),("DBP (mmHg)",COL["dbp"]),("FBG (mg/dL)",COL["fbg"]),
           ("TG (mg/dL)",COL["tg"]),("HDL-C (mg/dL)",COL["hdl"])]

def sex_table(d, sex, number):
    q=d[d[COL["sex"]].str.upper().eq(sex)].copy(); rows=[]; ps=[]
    for label,c in MARKERS:
        a=q.loc[q.MetS.eq(1),c].dropna().to_numpy(); b=q.loc[q.MetS.eq(0),c].dropna().to_numpy()
        test=stats.ttest_ind(a,b,equal_var=False); ps.append(test.pvalue)
        rows.append(dict(Parameter=label, MetS=f"{fmt_mean_sd(a)} (n={len(a)})", Non_MetS=f"{fmt_mean_sd(b)} (n={len(b)})",
                         t=test.statistic, P_value=test.pvalue, SMD=smd(a,b)))
    out=pd.DataFrame(rows); out["FDR_q_value"]=bh_adjust(ps)
    out.to_csv(TAB/f"Table_{number}_{'male' if sex=='M' else 'female'}_MetS_comparison.csv",index=False)
    return out

def correlation_figure(d):
    vars_=[COL['alt'],COL['ast'],COL['ggt'],'FLI_recalc','mHSI',COL['bmi'],COL['wc'],COL['sbp'],COL['dbp'],COL['fbg'],COL['tg'],COL['hdl']]
    labels=['ALT','AST','GGT','FLI','mHSI','BMI','WC','SBP','DBP','FBG','TG','HDL-C']
    corr=d[vars_].corr(method='pearson'); corr.index=labels; corr.columns=labels
    corr.to_csv(TAB/'Supplementary_correlation_matrix.csv')
    fig,ax=plt.subplots(figsize=(9,7.3)); sns.heatmap(corr,annot=True,fmt='.2f',cmap='coolwarm',vmin=-1,vmax=1,square=True,
        linewidths=.4,cbar_kws={'label':'Pearson correlation'},annot_kws={'size':7},ax=ax)
    ax.set_title('Correlations between hepatic markers and cardiometabolic measures',pad=12)
    fig.tight_layout(); fig.savefig(FIG/'Figure_1_correlation_heatmap.png',dpi=300); plt.close(fig)

def fit_logit_or_ci(y, X, term):
    # Unpenalised logistic estimate with model-based covariance from the
    # observed information matrix. This avoids a hard dependency on statsmodels.
    names=['const']+list(X.columns); A=np.column_stack([np.ones(len(X)),X.to_numpy(float)])
    fit=LogisticRegression(C=1e10,solver='lbfgs',fit_intercept=False,max_iter=10000).fit(A,np.asarray(y))
    beta=fit.coef_[0]; prob=fit.predict_proba(A)[:,1]; w=prob*(1-prob)
    cov=np.linalg.pinv(A.T@(A*w[:,None])); j=names.index(term); b=beta[j]; se=np.sqrt(max(cov[j,j],0))
    z=b/se if se>0 else np.nan; p=2*stats.norm.sf(abs(z)) if np.isfinite(z) else np.nan
    return np.exp(b),np.exp(b-1.96*se),np.exp(b+1.96*se),p

def interaction_table_figure(d):
    rows=[]
    for label,c in [('ALT',COL['alt']),('AST',COL['ast']),('GGT',COL['ggt']),('FLI','FLI_recalc'),('mHSI','mHSI')]:
        z=(d[c]-d[c].mean())/d[c].std(ddof=1); X=pd.DataFrame({'age':d[COL['age']], 'sex':d.sex_bin, 'marker':z, 'interaction':z*d.sex_bin})
        OR,lo,hi,p=fit_logit_or_ci(d.MetS,X,'interaction'); rows.append(dict(Marker=label,Interaction_OR=OR,CI_low=lo,CI_high=hi,P_value=p))
    out=pd.DataFrame(rows); out.to_csv(TAB/'Supplementary_marker_by_sex_interactions.csv',index=False)
    fig,ax=plt.subplots(figsize=(7,4.2)); y=np.arange(len(out));
    ax.errorbar(out.Interaction_OR,y,xerr=[out.Interaction_OR-out.CI_low,out.CI_high-out.Interaction_OR],fmt='o',capsize=3)
    ax.axvline(1,color='black',ls='--',lw=1); ax.set_yticks(y,out.Marker); ax.invert_yaxis(); ax.set_xlabel('Marker-by-sex interaction OR (95% CI)')
    for i,r in out.iterrows(): ax.text(r.CI_high+0.04,i,f"p={r.P_value:.3g}",va='center',fontsize=8)
    fig.tight_layout(); fig.savefig(FIG/'Figure_2_marker_sex_interactions.png',dpi=300); plt.close(fig)

def bootstrap_auc_cut(y,p,B=BOOT):
    rng=np.random.default_rng(SEED); vals=[]; cuts=[]
    for _ in range(B):
        ix=rng.integers(0,len(y),len(y)); yy=y[ix]; pp=p[ix]
        if len(np.unique(yy))<2: continue
        vals.append(roc_auc_score(yy,pp)); fpr,tpr,thr=roc_curve(yy,pp); ok=np.isfinite(thr); cuts.append(thr[ok][np.argmax((tpr-fpr)[ok])])
    fpr,tpr,thr=roc_curve(y,p); ok=np.isfinite(thr); cut=thr[ok][np.argmax((tpr-fpr)[ok])]
    return roc_auc_score(y,p),np.percentile(vals,[2.5,97.5]),cut,np.percentile(cuts,[2.5,97.5])

def marker_operating_metrics(y,p,cut):
    cls=np.asarray(p)>=cut
    tn,fp,fn,tp=confusion_matrix(y,cls,labels=[0,1]).ravel()
    return (tp/(tp+fn),tn/(tn+fp),tp/(tp+fp) if tp+fp else np.nan,
            tn/(tn+fn) if tn+fn else np.nan)

def paired_bootstrap_auc_difference(y,p,p_ref,B=BOOT):
    rng=np.random.default_rng(SEED); i0=np.where(y==0)[0]; i1=np.where(y==1)[0]; vals=[]
    for _ in range(B):
        ix=np.r_[rng.choice(i0,len(i0),True),rng.choice(i1,len(i1),True)]
        vals.append(roc_auc_score(y[ix],p[ix])-roc_auc_score(y[ix],p_ref[ix]))
    vals=np.asarray(vals); point=roc_auc_score(y,p)-roc_auc_score(y,p_ref)
    p_two=min(1.0,2*min((np.sum(vals<=0)+1)/(len(vals)+1),(np.sum(vals>=0)+1)/(len(vals)+1)))
    return point,np.percentile(vals,[2.5,97.5]),p_two

def roc_tables_figures(d):
    pred=[('ALT',COL['alt']),('AST',COL['ast']),('GGT',COL['ggt']),('FLI','FLI_recalc'),('mHSI','mHSI')]
    for outcome,fig_no in [('MetS','3A'),('MetS_star','3B')]:
        fig,axs=plt.subplots(1,3,figsize=(12,3.8)); rows=[]
        for ax,(group,mask) in zip(axs,[('Overall',np.ones(len(d),bool)),('Female',d.sex_bin.eq(1).to_numpy()),('Male',d.sex_bin.eq(0).to_numpy())]):
            y=d.loc[mask,outcome].to_numpy()
            alt=d.loc[mask,COL['alt']].to_numpy()
            for label,c in pred:
                p=d.loc[mask,c].to_numpy(); auc,ci,cut,cutci=bootstrap_auc_cut(y,p)
                sens,spec,ppv,npv=marker_operating_metrics(y,p,cut)
                if label=='ALT': delta=0.0; dlo=0.0; dhi=0.0; pval=np.nan
                else: delta,(dlo,dhi),pval=paired_bootstrap_auc_difference(y,p,alt)
                rows.append(dict(Outcome=outcome,Group=group,Marker=label,AUC=auc,AUC_CI_low=ci[0],AUC_CI_high=ci[1],Youden_cutpoint=cut,Cutpoint_CI_low=cutci[0],Cutpoint_CI_high=cutci[1],Sensitivity=sens,Specificity=spec,PPV=ppv,NPV=npv,Delta_AUC_vs_ALT=delta,Delta_AUC_CI_low=dlo,Delta_AUC_CI_high=dhi,Paired_bootstrap_p=pval))
                fpr,tpr,_=roc_curve(y,p); ax.plot(fpr,tpr,label=f'{label} {auc:.3f}')
            ax.plot([0,1],[0,1],'k--',lw=.8); ax.set_title(group); ax.set_xlabel('1 - Specificity'); ax.set_ylabel('Sensitivity'); ax.legend(fontsize=7)
        fig.tight_layout(); fig.savefig(FIG/f'Figure_{fig_no}_ROC_{outcome}.png',dpi=300); plt.close(fig)
        pd.DataFrame(rows).to_csv(TAB/f'Supplementary_Table_4_{outcome}_ROC.csv',index=False)

def supplementary_model_diagnostics():
    res=pd.read_csv(MODEL_OUT/'all_model_results.csv')
    dca=pd.read_csv(MODEL_OUT/'exploratory_decision_curve.csv')
    selected=[('Age+Sex','LR','Age + sex base'),('Enzymes only','LR','Enzymes only'),
              ('Age+Sex+FLI','LR','Age + sex + FLI'),('mHSI only','LR','mHSI only')]
    rows=[]
    for fam,alg,label in selected:
        x=res[(res.Model_family==fam)&(res.Algorithm==alg)].iloc[0]
        mean_nb=dca[(dca.Model_family==fam)&(dca.Algorithm==alg)].Net_benefit.mean()
        rows.append({'Model':label,'Brier_score':x.Brier,'Calibration_slope':x.Cal_slope,
                     'Calibration_intercept':x.Cal_intercept,
                     'Mean_exploratory_net_benefit_0.05_to_0.30':mean_nb})
    pd.DataFrame(rows).to_csv(TAB/'Supplementary_Table_8_calibration_decision_utility.csv',index=False)

    hp=pd.DataFrame([
      {'Algorithm':'Logistic regression','Preprocessing':'StandardScaler fitted within each training fold','Hyperparameter_search_space':'C: 0.01, 0.1, 1, 10; liblinear solver; maximum 5,000 iterations','Resampling':'5-fold stratified outer CV; 4-fold stratified inner CV','Class_weighting':'None'},
      {'Algorithm':'Random forest','Preprocessing':'None','Hyperparameter_search_space':'150 trees; maximum depth: 3 or 5; minimum leaf size: 5; maximum features: square root','Resampling':'5-fold stratified outer CV; 4-fold stratified inner CV','Class_weighting':'None'}])
    hp.to_csv(TAB/'Supplementary_Table_9_hyperparameters.csv',index=False)

    cm=res[['Model_family','Algorithm','Threshold_mean','TN','FP','FN','TP','Accuracy']].copy()
    cm.to_csv(TAB/'Supplementary_Table_10_confusion_matrices.csv',index=False)

def adjusted_associations(d):
    rows=[]
    for outcome in ['MetS','MetS_star']:
        for label,c in [('ALT',COL['alt']),('AST',COL['ast']),('GGT',COL['ggt']),('FLI','FLI_recalc'),('mHSI','mHSI')]:
            z=(d[c]-d[c].mean())/d[c].std(ddof=1)
            X=pd.DataFrame({'marker':z,'age':d[COL['age']]})
            adjustment='Age'
            if label!='mHSI': X['sex']=d.sex_bin; adjustment='Age and sex'
            OR,lo,hi,p=fit_logit_or_ci(d[outcome],X,'marker')
            rows.append(dict(Marker=label,Outcome=outcome,OR_per_SD=OR,CI_low=lo,CI_high=hi,Adjustment=adjustment,P_value=p))
    all_rows=pd.DataFrame(rows)
    all_rows.to_csv(TAB/'Supplementary_adjusted_associations_both_outcomes.csv',index=False)
    selected=((all_rows.Marker.eq('FLI') & all_rows.Outcome.eq('MetS_star')) | (~all_rows.Marker.eq('FLI') & all_rows.Outcome.eq('MetS')))
    all_rows.loc[selected].to_csv(TAB/'Table_5_adjusted_associations.csv',index=False)

def table6():
    f=MODEL_OUT/'all_model_results.csv'
    if not f.exists(): raise FileNotFoundError('Run reviewer2_reanalysis.py first')
    x=pd.read_csv(f)
    keep=['Model_family','Algorithm','AUC','AUC_CI_low','AUC_CI_high','Brier','Cal_intercept','Cal_slope','Threshold_mean','Sensitivity','Sensitivity_CI_low','Sensitivity_CI_high','Specificity','Specificity_CI_low','Specificity_CI_high','PPV','NPV','Accuracy','TN','FP','FN','TP']
    x[keep].to_csv(TAB/'Table_6_all_LR_and_RF_models.csv',index=False)

def nri_idi_table(d):
    f=MODEL_OUT/'incremental_nested_oof_results.csv'
    if not f.exists(): raise FileNotFoundError('Run reviewer2_reanalysis.py first')
    out=pd.read_csv(f)
    out.to_csv(TAB/'Table_7_incremental_predictive_value.csv',index=False)

def permutation_figure(d):
    # Recreate the RF outer-training fits using the exact original folds,
    # tuning grid and seeds; evaluate importance only on outer-test data.
    y=d.MetS_star.to_numpy()
    families={'Age+Sex+FLI':[COL['age'],'sex_bin','FLI_recalc'],
              'Age+mHSI':[COL['age'],'mHSI'],
              'Age+Sex+enzymes':[COL['age'],'sex_bin',COL['alt'],COL['ast'],COL['ggt']]}
    from sklearn.model_selection import GridSearchCV
    rows=[]; summaries=[]
    for fam,cols in families.items():
        X=d[cols].to_numpy(float)
        outer=StratifiedKFold(5,shuffle=True,random_state=SEED)
        for fold,(tr,te) in enumerate(outer.split(X,y)):
            inner=StratifiedKFold(4,shuffle=True,random_state=20262000+fold)
            rf=Pipeline([('model',RandomForestClassifier(n_estimators=150,
                min_samples_leaf=5,max_features='sqrt',random_state=100+fold,n_jobs=-1))])
            gs=GridSearchCV(rf,{'model__max_depth':[3,5]},scoring='roc_auc',cv=inner,n_jobs=-1)
            gs.fit(X[tr],y[tr])
            pi=permutation_importance(gs.best_estimator_,X[te],y[te],scoring='roc_auc',
                n_repeats=10,random_state=SEED+fold,n_jobs=-1)
            for j,c in enumerate(cols):
                for repeat,value in enumerate(pi.importances[j]):
                    rows.append({'Model':fam,'Feature':c,'Outer_fold':fold+1,
                        'Repeat':repeat+1,'Importance':float(value)})
    detail=pd.DataFrame(rows)
    detail.to_csv(TAB/'Supplementary_permutation_importance_by_fold.csv',index=False)
    out=detail.groupby(['Model','Feature']).Importance.agg(['mean','std']).reset_index()
    out=out.rename(columns={'mean':'Importance','std':'SD'}).sort_values('Importance')
    out.to_csv(TAB/'Supplementary_permutation_importance.csv',index=False)
    labels={COL['age']:'Age','sex_bin':'Female','FLI_recalc':'FLI','mHSI':'mHSI',
            COL['alt']:'ALT',COL['ast']:'AST',COL['ggt']:'GGT'}
    lab=out.Model+' | '+out.Feature.map(labels)
    fig,ax=plt.subplots(figsize=(8,5))
    ax.barh(lab,out.Importance,xerr=out.SD,color='#4a9d69',alpha=.9)
    ax.set_xlabel('Mean decrease in outer-test-fold AUC after permutation')
    fig.tight_layout();fig.savefig(FIG/'Figure_4_permutation_importance.png',dpi=300);plt.close(fig)

def calibration_dca_figure(d):
    # Use the exact nested out-of-fold predictions used in Table 6; do not
    # refit a separate fixed-hyperparameter model for the calibration panel.
    pred_file=MODEL_OUT/'nested_oof_predictions.csv'
    if not pred_file.exists(): raise FileNotFoundError('Run reviewer2_reanalysis.py first')
    nested=pd.read_csv(pred_file); y=nested.MetS_star.to_numpy()
    p=nested['Age_Sex_FLI_LR_probability'].to_numpy()
    fig,axs=plt.subplots(1,2,figsize=(9,3.8)); bins=pd.qcut(p,5,duplicates='drop'); cal=pd.DataFrame({'p':p,'y':y,'bin':bins}).groupby('bin',observed=True).agg(mean_p=('p','mean'),obs=('y','mean'))
    axs[0].plot([0,1],[0,1],'k--'); axs[0].plot(cal.mean_p,cal.obs,'o-',label='Age + sex + FLI LR'); axs[0].set(xlabel='Mean predicted probability',ylabel='Observed proportion',title='Out-of-fold calibration'); axs[0].legend(fontsize=8)
    dca=pd.read_csv(MODEL_OUT/'exploratory_decision_curve.csv'); q=dca[(dca.Model_family=='Age+Sex+FLI')&(dca.Algorithm=='LR')]
    axs[1].plot(q.Threshold_probability,q.Net_benefit,label='Age + sex + FLI LR'); prev=y.mean(); pt=q.Threshold_probability.to_numpy(); axs[1].plot(pt,prev-(1-prev)*pt/(1-pt),ls='--',label='Treat all'); axs[1].axhline(0,color='black',lw=.8,label='Treat none')
    axs[1].set(xlabel='Threshold probability',ylabel='Net benefit',title='Exploratory decision-curve analysis'); axs[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(FIG/'Figure_5_calibration_decision_curve.png',dpi=300); plt.close(fig)

def main():
    d=load_data(); sex_table(d,'M',1); sex_table(d,'F',2); correlation_figure(d); interaction_table_figure(d)
    roc_tables_figures(d); adjusted_associations(d); table6(); nri_idi_table(d); supplementary_model_diagnostics(); permutation_figure(d); calibration_dca_figure(d)
    with pd.ExcelWriter(OUT/'All_manuscript_tables.xlsx',engine='openpyxl') as w:
        for i,f in enumerate(sorted(TAB.glob('*.csv')),1):
            pd.read_csv(f).to_excel(w,sheet_name=str(i).zfill(2)+'_'+f.stem[:28],index=False)
    print(f'Created tables in {TAB}')
    print(f'Created figures in {FIG}')
    print(f'Created workbook {OUT / "All_manuscript_tables.xlsx"}')

if __name__=='__main__': main()
