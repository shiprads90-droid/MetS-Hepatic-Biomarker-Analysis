from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parent
if not os.environ.get("METS_DATA"):
    raise SystemExit("Set METS_DATA to the source Excel workbook path first.")
for script in ["reviewer2_reanalysis.py", "manuscript_tables_figures.py", "check_generated_tables.py"]:
    subprocess.run([sys.executable,str(root/script)],check=True,cwd=root)
